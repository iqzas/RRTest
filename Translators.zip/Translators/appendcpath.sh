#!/bin/ksh

#
# Set all the jars in the Translators Directory in the CPATH variable.
# This file is invoked by Translation Module startup script.
# This file is expected to be in Module/Translators directory.
#

export COMPUTERNAME=`hostname -s`
# echo ${COMPUTERNAME}

export TCPB_JAR_PATH=${TSTK_ROOT}/Module/Translators/tcpbcreateimage/lib
#CPATH=$CPATH:$TS_HOME/Translators/proetojt/proetojt.jar:${TCPB_JAR_PATH}/TCPB_CreateImage.jar
CPATH=$CPATH:$TS_HOME/Translators/proetojt/proetojt.jar

# 19.03.2018 ng008133 & tka00729 # Add all of the Jar files in the
# tcpbcreateimagedirectory and its ant subdirectory to the CPATH env variable
for i in ${TCPB_JAR_PATH}/*.jar
do
  CPATH=$CPATH:$i
done
for i in ${TCPB_JAR_PATH}/ant/*.jar
do
  CPATH=$CPATH:$i
done
#echo ${CPATH}
