This directory includes certain common logic elements that are supplied AS-IS to include in your specific translation logic.

Per logic element, we add here:
- a <logic>.properties file to contain configuration properties specific to this translation/report logic
- a <logic>.xml properties file to implement an Apache ANT project

*ALL* translation options will be passed along to us here with their original names. For example, iid=4711, irv=A will be available as ${iid} in our ANT-projects.

Our dispatcher request provides us with the logic to be executed as translator option:
	logic=<logic>