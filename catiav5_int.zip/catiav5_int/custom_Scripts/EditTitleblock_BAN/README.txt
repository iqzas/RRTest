Pfade Makro (angepasste Kopie f�r BAN der Version in LAP)
\\samba-in\cadsettings\v5r18_global\_Macros\TeamCenter\EditTitleblock\EditTitleBlockData.CATScript
\\samba-in\cadsettings\v5r18_global\_Macros\TeamCenter_E\EditTitleblock\EditTitleBlockData.CATScript
\\samba-in\cadsettings\v5r18_global\_Macros\TeamCenter_Q\EditTitleblock\EditTitleBlockData.CATScript

Pfad Makro (Original in LAP - verantwortlich FB)
K:\datalp\SOFTWARE\catiav5\macros\develop\EditTitleBlock\EditTitleBlockData.CATScript

Pfad Drawing
\\samba-in\cadsettings\v5r18_global\_Standards\TeamCenter\EditTitleblock\Catalog_bcrc.CATDrawing